<?php  
 //test_class.php  
include 'Classes/database.php';  
 $data = new Databases;  
 $success_message = '';  
  if(isset($_POST["submit"]))  
 {  
      $insert_data = array(  
           'username'     =>      $_POST['username'],  
           'password'     =>     $_POST['password']  ,
		   'admin'     =>      $_POST['admin']  ,
		    'email'    =>     $_POST['email' ] ,
		   
      );  
      if($data->insert('UserName', $insert_data))  
      {  
           $success_message = 'Post Inserted';  
      }       
 }  
 if(isset($_POST["edit"]))  
 {  
      $update_data = array(  
          'password'     =>      $_POST['password'],  
           'admin'     =>     $_POST['admin']  ,
		   'email'     =>      $_POST['email']  ,
		    
		   'username'          =>     $_POST['username']  
      );  
      $where_condition = array(  
           'username'     =>     $_POST["username"]  
      );  
      if($data->update("UserName", $update_data, $where_condition))  
      {  
           header("location:admin.php?updated=1");  
      }  
 }  
 if(isset($_GET["updated"]))  
 {  
      $success_message = 'Post Updated';  
 }  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Select or Fetch Data from Mysql Table using OOPS in PHP</title>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
			
      </head>  
      <body>  
           <br /><br />  
           <div class="container" style="width:700px;">  
                <form method="post">  
				 <?php  
                     if(isset($_GET["edit"]))  
                     {  
                          if(isset($_GET["username"]))  
                          {  
                               $where = array(  
                                    'username'     =>     $_GET["username"]  
                               );  
                               $single_data = $data->select_where("UserName", $where);  
                               foreach($single_data as $post)  
                               {  
                     ?> 
					  <label>Password</label><input type="text" name="password"  value="<?php echo $post->password; ?>"  class="form-control" />  
				      <label>admin</label> <input type="text" name="admin" value="<?php echo $post->admin; ?>"  class="form-control" />  
					  <label>email</label> <input type="text" name="email" value="<?php echo $post->email; ?>"  class="form-control" />  
				      <input type="hidden" name="username" value="<?php echo $post->username; ?>" />  
                      <input type="submit" name="edit" class="btn btn-info" value="Edit" />  
                     <?php  
                               }  
                          }  
                     }  
                     else  
                     {  
                     ?>  					 
                     <label>username</label><input type="text" name="username" class="form-control" />  
					 <label>password</label> <input type="text" name="password" class="form-control" />  
					  <label>admin</label> <input type="text" name="admin" class="form-control" />  
					   <label>email</label> <input type="text" name="email" class="form-control" />  
                     
                     <br />  
                     <input type="submit" name="submit" class="btn btn-info" value="Submit" />  
					  <?php  
                     }  
                     ?>  
                     <span class="text-success">  
                     <?php  
                     if(isset($success_message))  
                     {  
                          echo $success_message;  
                     }  
                     ?>  
                     </span>  
                </form>  
                <br />  
                <div class="table-responsive">  
                     <table class="table table-bordered">  
                          <tr>  
                               <td width="10%">username</td>  
							   <td width="10%">password</td>  
							   <td width="10%">admin</td>  
							   <td width="10%">email</td>  
                               <td width="10%">Edit</td>  
                               <td width="10%">Delete</td>  
                          </tr>  
                          <?php  
                          $post_data = $data->select('UserName');  
						  
                          foreach($post_data as $post)  
                          {  
                          ?>  
                          <tr>  
						       <td><?php echo $post->username; ?></td>  
                               <td><?php echo $post->password; ?></td>  
							    <td><?php echo $post->admin; ?></td>  
							   <td><?php echo $post->email; ?></td>  
							   
						       
								<td><a href="admin.php?edit=1&username=<?php echo $post->username; ?>">Edit</a></td>  
                               <td><a href="#" id="<?php echo $post->username; ?>" class="delete">Delete</a></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  
                </div>
                  <a href="index.php">Return to main menu</a>			
           </div>  
      </body>  
 </html>  