<?php
session_start();
// Change this to your connection info.
     
			 $con = new PDO('sqlite:db/products.db');
			 $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			  
			// die();
		 // Now we check if the data from the login form was submitted, isset() will check if the data exists.
if ( !isset($_POST['username'], $_POST['password']) ) {
	// Could not get the data that should have been sent.
	die ('Please fill both the username and password field!');
}
else 
{
         unset ($_SESSION['username']);
		 unset ($_SESSION['loggedin']);
		  unset ( $_SESSION["admin"]);
    if ($stmt = $con->prepare('SELECT  username,admin,password FROM UserName WHERE username =:user  and password =:password ' )) {
	//  if ($stmt = $con->prepare('SELECT  username,admin,password FROM UserName WHERE username =:user    ' )) {
	// Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"
	  $stmt->bindValue(':user', $_POST['username'],PDO::PARAM_STR);
	  $stmt->bindValue(':password', $_POST['password'],PDO::PARAM_STR);
	  $count = 0;
	
      if( $stmt->execute() ){
			$count = $stmt->rowcount();
	 	//	echo "count=" .$count." ".$_POST['username']."";
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){ 
			 $count = 1;
			 echo '<h3> Role: '. htmlentities($row['admin']). '</h3>';
			 $admin = htmlentities($row['admin']);
			  $_SESSION["admin"] = $admin;
			}
	}
	 
	// Store the result so we can check if the account exists in the database.
     //  $taskid =$stmt->rowcount();
 	 
	$con = null;
	//echo "<h1> Search Results </h1>";
   // echo "count=" .$count. "";
  
    if ($count == 0 )   // count = 0 means valid 
        {
            echo '<h2> Invalid Username/Password  Try Again!</h2>';
            echo '<a href="index.php">Return to main menu</a>';
        }
	else
		{
			echo '<h3> Valid  Username  !</h3>';
			// echo '<h3> Role: '. htmlentities($row['password']). '</h3>';
		     echo '<h3> Login Successful! </h3>';
			$_SESSION['loggedin'] = TRUE;
		   header('Location: index.php');
		}

}//	$stmt->close();
} // else 
?>
 