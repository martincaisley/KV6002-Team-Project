<?php   
 //database.php  
function autoloadClasses($className) {
	    $filename = "classes/" . $className . ".php";
	    if (is_readable($filename)) {
	        include $filename;
	    }
	}

	spl_autoload_register("autoloadClasses");

 class Databases{  
      
	 

	//spl_autoload_register("autoloadClasses");
	  
      public function insert($table_name, $data)  
      {  
           $string = "INSERT INTO ".$table_name." (";            
           $string .= implode(",", array_keys($data)) . ') VALUES (';            
           $string .= "'" . implode("','", array_values($data)) . "')";  
		    $pdo = new PDO("sqlite:db/products.db");
          $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
		   try {
           if($pdo->query($string))  
           {  
                return true;  
           }  
            } catch (Exception $e){
	    	echo "<p>Query failed: ".$e->getMessage()."</p>\n";
	      }
      }  
	  
      public function select($table_name)  
      {  
	      $pdo = new PDO("sqlite:db/products.db");
          $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);		  
		  //  $dbConn = pdoDB::getConnection();
           $array = array();  
		    try {
           $sqlquery = "SELECT * FROM ".$table_name."";  
	   //    $sqlquery = "SELECT * FROM Windows ";  
		   $result = $pdo->query($sqlquery);
		   $dbConn = null;
	      } catch (Exception $e){
	    	echo "<p>Query failed: ".$e->getMessage()."</p>\n";
	      }
           while ($row = $result->fetchObject()) {
		
                $array[] = $row;  
           }  
           return $array;  
      }  
	  
	 public function select_where($table_name, $where_condition)  
      {  
           $condition = '';  
           $array = array();  
		   
		    $pdo = new PDO("sqlite:db/products.db");
          $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		  
           foreach($where_condition as $key => $value)  
           {  
                $condition .= $key . " = '".$value."' AND ";  
           }  
           $condition = substr($condition, 0, -5);  
           $sqlquery = "SELECT * FROM ".$table_name." WHERE " . $condition;  
           $result = $pdo->query($sqlquery);
           while ($row = $result->fetchObject()) {
           $array[] = $row;  
           }  
           return $array;  
      }  
      public function update($table_name, $fields, $where_condition)  
      {  
           $query = '';  
           $condition = '';  
           foreach($fields as $key => $value)  
           {  
                $query .= $key . "='".$value."', ";  
           }  
           $query = substr($query, 0, -2);  
           /*This code will convert array to string like this-  
           input - array(  
                'key1'     =>     'value1',  
                'key2'     =>     'value2'  
           )  
           output = key1 = 'value1', key2 = 'value2'*/  
           foreach($where_condition as $key => $value)  
           {  
                $condition .= $key . "='".$value."' AND ";  
           }  
           $condition = substr($condition, 0, -5);  
           /*This code will convert array to string like this-  
           input - array(  
                'id'     =>     '5'  
           )  
           output = id = '5'*/  
		   
		   
           $query = "UPDATE ".$table_name." SET ".$query." WHERE ".$condition."";  
		    $pdo = new PDO("sqlite:db/products.db");
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            try {
           if($pdo->query($query))  
           {  
                return true;  
           }  
            } catch (Exception $e){
	    	echo "<p>Query failed: ".$e->getMessage()."</p>\n";
	      }
      }  
	  
	  
	  
 }  
 ?>  